"""
Configuration management for MCP Server
"""