"""
Core services for MCP Server
"""