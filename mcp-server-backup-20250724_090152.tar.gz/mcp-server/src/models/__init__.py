"""
Data models for MCP Server
"""