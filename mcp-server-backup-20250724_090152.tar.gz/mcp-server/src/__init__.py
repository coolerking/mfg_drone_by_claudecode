"""
MCP Server - Model Context Protocol Server for Drone Control
"""

__version__ = "1.0.0"
__author__ = "MFG Drone MCP Server"