"""
Tests for MCP Server
"""