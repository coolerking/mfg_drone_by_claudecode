# This file has been removed as it was testing deleted FastAPI functionality
# The MCP server now uses stdio communication, not HTTP endpoints
# For MCP server testing, use test_mcp_server.py instead